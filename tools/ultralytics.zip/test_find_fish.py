from ultralytics import YOLO

# Create a new YOLO model from scratch
model = YOLO('yolov8m.yaml')

# Load a pretrained YOLO model (recommended for training)
model = YOLO('runs/yolov8/Find_fish/base6/weights/best.pt')

# Train the model
results = model.val(data='find_fish-data.yaml', split='test', save_json=True, batch=16, conf=0.168)
# results = model.val(data='find_fish-data.yaml', split='val', save_json=True, batch=32)