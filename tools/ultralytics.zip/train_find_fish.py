from ultralytics import YOLO

# Create a new YOLO model from scratch
model = YOLO('yolov8x.yaml')

# Load a pretrained YOLO model (recommended for training)
model = YOLO('yolov8x-oiv7.pt')
# model = YOLO('/mnt/c/Users/김동영/Downloads/AIFactory/ultralytics/runs/yolov8/Find_fish/base5/weights/last.pt')

# Train the model
results = model.train(data='find_fish-data.yaml', cfg='find_fish_new.yaml')
# results = model.train(data='find_fish-data.yaml', cfg='find_fish_new.yaml', resume=True)